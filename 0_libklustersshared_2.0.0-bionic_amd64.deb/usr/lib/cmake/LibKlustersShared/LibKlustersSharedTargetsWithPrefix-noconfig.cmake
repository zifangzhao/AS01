#----------------------------------------------------------------
# Generated CMake target import file.
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "klustersshared" for configuration ""
set_property(TARGET klustersshared APPEND PROPERTY IMPORTED_CONFIGURATIONS NOCONFIG)
set_target_properties(klustersshared PROPERTIES
  IMPORTED_LINK_INTERFACE_LIBRARIES_NOCONFIG "/usr/lib/x86_64-linux-gnu/libQtWebKit.so;/usr/lib/x86_64-linux-gnu/libQtGui.so;/usr/lib/x86_64-linux-gnu/libQtCore.so"
  IMPORTED_LOCATION_NOCONFIG "/usr/lib/libklustersshared.so.2.0.0"
  IMPORTED_SONAME_NOCONFIG "libklustersshared.so.2"
  )

list(APPEND _IMPORT_CHECK_TARGETS klustersshared )
list(APPEND _IMPORT_CHECK_FILES_FOR_klustersshared "/usr/lib/libklustersshared.so.2.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
